import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GreetingService {

  constructor() { }

  // We added this.
  getGreeting() : string {
    return "My Uber Cool App";
  }
  
}
