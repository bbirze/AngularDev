import {Component, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

// Import and register some locales.
import {registerLocaleData} from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import localeDe from '@angular/common/locales/de';
import localeJa from '@angular/common/locales/ja';
registerLocaleData(localeFr);
registerLocaleData(localeDe);
registerLocaleData(localeJa);

@Component({
    selector: 'message',
    templateUrl: 'person.html'
})
class PersonComponent {
  
    rating: number;
    salary: number;
    timestamp: Date;
    
    selectedLocale: String;
	
    constructor() {
        this.rating = 0.9874754654;
        this.salary = 1500000.99; 
        this.timestamp = new Date();
		this.selectedLocale = "en";
    }
}

// Wrap our component in a module.
@NgModule({
    imports: [BrowserModule, FormsModule],
    declarations: [PersonComponent],
    bootstrap: [PersonComponent]
})
export class AppModule {}

// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

