import {Component, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

@Component({
    selector: 'message',
    templateUrl: 'person.html'
})
class PersonComponent {
  
    birthCountry: string;
    workCountry:  string;
    holsCountry:  string;
    
    countryMapping = {
        'UK': 'United Kingdom', 
        'NO': 'Norway',
        'FR': 'France',
        '??': 'Other'
    };

    constructor() {
        this.birthCountry = 'UK';
        this.workCountry  = 'NO';
        this.holsCountry  = '??';
    }
}

// Wrap our component in a module.
@NgModule({
    imports: [BrowserModule],
    declarations: [PersonComponent],
    bootstrap: [PersonComponent]
})
export class AppModule {}

// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

