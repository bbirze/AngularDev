import {Component, NgModule} from '@angular/core';
import {UpperCasePipe, LowerCasePipe, DatePipe} from '@angular/common';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
 
@Component({
    selector: 'message',
    templateUrl: 'person.html',
    providers: [UpperCasePipe, LowerCasePipe, DatePipe]
})
class PersonComponent {
  
    // Original data.
    name = 'Gylfi Sigurdsson';
    timestamp = new Date();
    
    // Tranformed data.
    nameUC: string;
    nameLC: string;
    timestampDate: string;
    timestampTime: string;

    constructor(ucPipe: UpperCasePipe, lcPipe: LowerCasePipe, dtPipe: DatePipe) {

        this.nameUC = ucPipe.transform(this.name);
        this.nameLC = lcPipe.transform(this.name);
        
        this.timestampDate = dtPipe.transform(this.timestamp);        
        this.timestampTime = dtPipe.transform(this.timestamp, 'hh:mm:ss a');
    }
}

// Wrap our component in a module.
@NgModule({
    imports: [BrowserModule],
    declarations: [PersonComponent],
    bootstrap: [PersonComponent]
})
export class AppModule {}

// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

