import {Component, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormGroup, FormControl, Validators, FormBuilder, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';


// Define a class to represent a single product.
class Product {
    constructor(
        public description?: string, 
        public category?: string, 
        public lowPrice?: number,
        public highPrice?: number,
    ) {}
}


// Version 1 of an Angular component, to display a product in a form. 
// This component creates FormControls manually.
// To use this component in the demo, ensure the @NgModule at the bottom of the code bootstraps ProductForm1Component.
@Component({
    selector:    'product-form', 
    templateUrl: 'product-form.html', 
    styleUrls:  ['product-form.css']
})
class ProductForm1Component implements OnInit {

    caption = 'Form 1, creating FormControls manually';
    productForm: FormGroup;
    products: Array<Product> = [];
 
    ngOnInit() {
        this.productForm = new FormGroup({
            description: new FormControl('', Validators.required),
            category: new FormControl('', Validators.required),
            pricePolicy: new FormGroup({
                lowPrice: new FormControl(''),
                highPrice: new FormControl('')
            })
        });
    }

    onSubmit(form: FormGroup) { 
        let product = new Product(
            form.controls.description.value,
            form.controls.category.value,
            form.controls.pricePolicy.controls.lowPrice.value,
            form.controls.pricePolicy.controls.highPrice.value);
        this.products.push(product);
        form.reset();
    }
}


// Version 2 of an Angular component, to display a product in a form. 
// This component uses an injected FormBuilder, to simplify building the form.
// To use this component in the demo, ensure the @NgModule at the bottom of the code bootstraps ProductForm2Component.
@Component({
    selector:    'product-form', 
    templateUrl: 'product-form.html', 
    styleUrls:  ['product-form.css'],
    providers:  [FormBuilder]
})
class ProductForm2Component implements OnInit {

    caption = 'Form 2, using FormBuilder';
    productForm: FormGroup;
    products: Array<Product> = [];
 
    constructor(private formBuilder: FormBuilder) {}
    
    ngOnInit() {
        this.productForm = this.formBuilder.group({
            description: ['', Validators.required],
            category: ['', Validators.required],
            pricePolicy: this.formBuilder.group({
                lowPrice: '',
                highPrice: ''
            })
        });
    }

    onSubmit(form: FormGroup) { 
        let product = new Product(
            form.controls.description.value,
            form.controls.category.value,
            form.controls.pricePolicy.controls.lowPrice.value,
            form.controls.pricePolicy.controls.highPrice.value);
        this.products.push(product);
        form.reset();
    }
}


// Wrap our components in a module.
// Set the bootstrap property to either ProductForm1Component or ProductForm2Component.
@NgModule({
    imports: [BrowserModule, FormsModule, ReactiveFormsModule],
    declarations: [ProductForm1Component, ProductForm2Component],
    bootstrap: [ProductForm1Component]
})
export class AppModule {}


// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

