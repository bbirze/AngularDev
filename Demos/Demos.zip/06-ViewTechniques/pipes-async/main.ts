import {Component, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

import {Observable, interval} from 'rxjs';
import {map} from 'rxjs/operators';

class Goal {
    constructor(public goalNumber: number, public goalTimestamp: Date) {}
}

@Component({
    selector: 'message',
    templateUrl: 'person.html'
})
class PersonComponent {
  
    firstGoal:      Promise<Date>;
    mostRecentGoal: Observable<Goal>;

    constructor() {

        this.firstGoal = new Promise(function(resolve, reject) {
            setTimeout(function() {
                resolve(new Date());
            }, 3000)
        });

        this.mostRecentGoal = interval(3000).
                                  pipe(map(n => new Goal(n+1, new Date())));
    }
}

// Wrap our component in a module.
@NgModule({
    imports: [BrowserModule],
    declarations: [PersonComponent],
    bootstrap: [PersonComponent]
})
export class AppModule {}

// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

