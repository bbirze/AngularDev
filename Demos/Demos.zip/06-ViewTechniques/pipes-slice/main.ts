import {Component, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

@Component({
    selector: 'message',
    templateUrl: 'person.html'
})
class PersonComponent {
  
    skills: Array<string>;
    
    constructor() {
        this.skills = ['Java', 'C#', 'HTML5', 'TypeScript', 'Angular'];
    }
}

// Wrap our component in a module.
@NgModule({
    imports: [BrowserModule],
    declarations: [PersonComponent],
    bootstrap: [PersonComponent]
})
export class AppModule {}

// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

