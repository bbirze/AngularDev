import {Component, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

@Component({
    selector: 'message',
    templateUrl: 'person.html'
})
class PersonComponent {
  
    name: string;
    team: string;
    rating: number;
    salary: number;
    email: string;
    timestamp: Date;
    additionalInfo: any;
    
    constructor() {
        this.name = 'Gylfi Sigurdsson';
        this.team = 'swansea city';
        this.rating = 0.9874754654;
        this.salary = 1500000.99; 
        this.email = 'gylfi@swans.com';
        this.timestamp = new Date();
        this.additionalInfo = {
            nationality: 'Iceland',
            age: 27,
            height: 1.83,
            car: 'Bugatti'
        };
    }
}

// Wrap our component in a module.
@NgModule({
    imports: [BrowserModule],
    declarations: [PersonComponent],
    bootstrap: [PersonComponent]
})
export class AppModule {}

// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

