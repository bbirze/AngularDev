import {Component, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

@Component({
    selector: 'message',
    templateUrl: 'person.html'
})
class PersonComponent {
  
    softSkills:      Array<string>;
    businessSkills:  Array<string>;
    frameworkSkills: Array<string>;
    languageSkills:  Array<string>;
    
    messageMapping = {
        '=0':    'No skills', 
        '=1':    'One skill',
        'other': '# skills'
    };

    constructor() {
        this.softSkills      = [];
        this.businessSkills  = ['Gathering requirements'];
        this.frameworkSkills = ['Angular', 'jQuery', 'Bootstrap'];
        this.languageSkills  = ['Java', 'C#', 'C++', 'Python', 'Cobol', 'JavaScript'];
    }
}

// Wrap our component in a module.
@NgModule({
    imports: [BrowserModule],
    declarations: [PersonComponent],
    bootstrap: [PersonComponent]
})
export class AppModule {}

// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

