import {Component, NgModule, Pipe, PipeTransform} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

@Pipe({name: 'flexiTitlecase'})
class FlexiTitleCasePipe implements PipeTransform {

    transform(value: string, ...args: any[]): string {

        if(value && (args[0] === 'upper' || args[0] === 'lower')) {
            let words:string[] = value.split(' ');
            for (var i = 0; i < words.length; i++) {
                if (args[0] === 'upper')
                    words[i] = words[i].charAt(0).toUpperCase() + words[i].slice(1).toLowerCase();
                else 
                    words[i] = words[i].charAt(0).toLowerCase() + words[i].slice(1).toUpperCase();
            }
            return words.join(' ');
        }
        else {
            return value;
        }
    }
  }
}

@Component({
    selector: 'message',
    templateUrl: 'person.html'
})
class PersonComponent {  
    name: string;
    constructor() {
        this.name = 'gylfi sigurdsson';
    }
}

// Wrap our component in a module.
@NgModule({
    imports: [BrowserModule],
    declarations: [PersonComponent, FlexiTitleCasePipe],
    bootstrap: [PersonComponent]
})
export class AppModule {}

// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

