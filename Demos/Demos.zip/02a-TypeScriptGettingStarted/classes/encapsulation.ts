class Employee {
    private _name: string;
    private _salary: number;

    constructor(_name: string, _salary: number) {
        this._name = _name;
        this._salary = _salary;
    }   
  
    get name(): string { 
        return this._name;
    }
  
    set name(newName: string) { 
        this._name = newName;
    }
  
    get salary(): number {
        return this._salary
    }
}

var emp1 = new Employee("Simon", 10000);
emp1.name = "Peter";
console.log(emp1.name + ' earns ' + emp1.salary);
