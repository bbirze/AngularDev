class Employee {

    constructor(private _name: string, private _salary: number) {}
 
    payRise(amount: number): void {
        this._salary += amount;
    }
  
    isHigherTaxPayer(): boolean {
        return this._salary > 42000;
    }
  
    set name(newName: string)  { 
        this._name = newName;
    }
  
    get salary(): number {
        return this._salary
    }
}

var emp1 = new Employee("Simon", 10000);
emp1.payRise(100000);
console.log("Higher tax? " + emp1.isHigherTaxPayer());
