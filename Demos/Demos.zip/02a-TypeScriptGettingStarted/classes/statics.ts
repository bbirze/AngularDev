class Employee {

    private static _taxThreshold: number = 42000;
  
    constructor(private _name: string, private _salary: number) {}   
 
    payRise(amount: number): void {
        this._salary += amount;
    }
  
    isHigherTaxPayer(): boolean {
        return this._salary > Employee._taxThreshold;
    }
  
    set name(newName: string) { 
        this._name = newName;
    }
  
    get salary(): number {
        return this._salary
    }
  
    static get taxThreshold(): number {
        return Employee._taxThreshold;
    }
}

var emp1 = new Employee("Simon", 10000);
emp1.payRise(100000);
console.log("Higher tax? " + emp1.isHigherTaxPayer());

// This statement causes an compiler error - 'Employee._taxThreshold' is inaccessible.
// console.log("Tax threshold is " + Employee._taxThreshold);

// This statement is OK.
console.log("Tax threshold is " + Employee.taxThreshold);
