class Employee {
	name: string;
	salary: number;
}

var emp1 = new Employee();
emp1.name = "Paul";
emp1.salary = 42000;