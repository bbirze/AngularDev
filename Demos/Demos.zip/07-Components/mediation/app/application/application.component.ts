import {Component} from '@angular/core';
import {Product, ProductService} from '../product-service/product-service';
import SaleListerComponent from '../sale-lister/sale-lister.component';
import {ISale} from '../sale/sale';

@Component({
    moduleId:     module.id,
    selector:    'osl-application', 
    templateUrl: 'application.component.html'
})
export default class ApplicationComponent {
    products: Array<Product> = []; 
    newSale: ISale;

    constructor() { 
        let productService = new ProductService();
        this.products = productService.getProducts(); 
    }
  
    saleHandler(event: ISale) {
        this.newSale = event;
    }  
}
