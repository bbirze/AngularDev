import {Component, Input} from '@angular/core';
import {Product, ProductService} from '../product-service/product-service';
import {ISale} from '../sale/sale';

@Component({
    moduleId:     module.id,
    selector:    'osl-sale-lister',
    templateUrl: 'sale-lister.component.html'
})
export default class SaleListerComponent {

    sales: Array<string> = [];

    private _newSale: ISale;
  
    @Input() set newSale(value: ISale) {
        if (value) {
          let msg:string = value.productDescription + ' [' + value.quantity + ']';
          this.sales.push(msg);
        }
    }

    get newSale(): ISale {
        return this._newSale;
    }
}
