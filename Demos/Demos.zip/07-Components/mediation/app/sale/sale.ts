export interface ISale {
    productDescription: string;
    quantity: number;
};
