import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';

import ApplicationComponent from './application/application'
import HeaderComponent from './header/header'
import FooterComponent from './footer/footer'

@NgModule({
    imports: [BrowserModule],
    declarations: [ApplicationComponent, HeaderComponent, FooterComponent],
    bootstrap: [ApplicationComponent]
})
export default class AppModule {}


