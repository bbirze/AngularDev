import {Component} from '@angular/core';

@Component({
    selector: 'osl-application', 
    templateUrl: 'app/application/application.html', 
    styleUrls:  ['app/application/application.css']
})
export default class ApplicationComponent {
  name: string;

  constructor() {
    this.name = 'Andy';
  }
}
