import {Component} from '@angular/core';

@Component({
    selector: 'osl-header',
    templateUrl: 'app/header/header.html',
    styleUrls:  ['app/header/header.css'] 
})
export default class HeaderComponent {}
