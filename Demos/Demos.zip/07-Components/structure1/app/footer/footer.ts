import {Component} from '@angular/core';

@Component({
    selector: 'osl-footer',
    templateUrl: 'app/footer/footer.html',
    styleUrls:  ['app/footer/footer.css'] 
})
export default class FooterComponent {}
