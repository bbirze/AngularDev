import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';

import ApplicationComponent from './application/application.component'
import ProductItemComponent from './product-item/product-item.component'

@NgModule({
    imports: [BrowserModule],
    declarations: [ApplicationComponent, ProductItemComponent],
    bootstrap: [ApplicationComponent]
})
export default class AppModule {}


