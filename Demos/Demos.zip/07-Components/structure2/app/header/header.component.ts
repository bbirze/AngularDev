import {Component, NgModule} from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'osl-header',
    templateUrl: 'header.component.html',
    styleUrls: ['header.component.css'], 
})
export default class HeaderComponent {

    constructor() {
        console.log(`The HeaderComponent's moduleId is ${module.id}`);
    } 
}
