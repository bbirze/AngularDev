import {Component} from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'osl-footer',
    templateUrl: 'footer.component.html',
    styleUrls: ['footer.component.css'] 
})
export default class FooterComponent {

    constructor() {
        console.log(`The FooterComponent's moduleId is ${module.id}`);
    } 
}