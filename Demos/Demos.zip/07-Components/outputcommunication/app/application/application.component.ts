import {Component} from '@angular/core';
import {Product, ProductService} from '../product-service/product-service';
import {ISale} from '../product-item/product-item.component';

@Component({
    moduleId:     module.id,
    selector:    'osl-application', 
    templateUrl: 'application.component.html'
})
export default class ApplicationComponent {
    products: Array<Product> = []; 
    sales: Array<string> = [];
  
    constructor() { 
        let productService = new ProductService();
        this.products = productService.getProducts(); 
    }
  
    saleHandler(event: ISale) {
        let msg:string = event.productDescription + ' [' + event.quantity + ']';
        this.sales.push(msg);
    }
}
