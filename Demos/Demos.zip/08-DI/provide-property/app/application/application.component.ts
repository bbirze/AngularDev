import {Component} from '@angular/core';
import {Product, ProductService, MockProductService} from '../product-service/product-service';


@Component({
    moduleId:     module.id,
    selector:    'osl-application', 
    templateUrl: 'application.component.html',

    // Uncomment one of the following lines, to determine which class will be injected.
    // providers: [{ provide: ProductService, useClass: ProductService}]
    providers: [{ provide: ProductService, useClass: MockProductService}]
})
export default class ApplicationComponent {
    products: Array<Product> = []; 

    constructor(productService : ProductService) { 
        this.products = productService.getProducts(); 
    }
}
