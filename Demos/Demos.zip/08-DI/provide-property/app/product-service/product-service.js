"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var Product = /** @class */ (function () {
    function Product(description, category, price) {
        this.description = description;
        this.category = category;
        this.price = price;
    }
    return Product;
}());
exports.Product = Product;
var ProductService = /** @class */ (function () {
    function ProductService() {
    }
    ProductService.prototype.getProducts = function () {
        var products = [
            new Product('Swansea City shirt', 'Leisure wear', 45),
            new Product('Cardiff City shirt', 'Leisure wear', 5),
            new Product('Bugatti Chiron', 'Auto', 2000000),
            new Product('65 inch UHDTV', 'TV/Audio', 1800),
            new Product('Carving skis', 'Sports equipment', 350),
            new Product('Ski boots', 'Sports equipment', 150)
        ];
        return products;
    };
    ProductService = __decorate([
        core_1.Injectable()
    ], ProductService);
    return ProductService;
}());
exports.ProductService = ProductService;
var MockProductService = /** @class */ (function () {
    function MockProductService() {
    }
    MockProductService.prototype.getProducts = function () {
        var products = [
            new Product('MOCK PROD1', 'MOCK DESC1', 111),
            new Product('MOCK PROD2', 'MOCK DESC2', 222)
        ];
        return products;
    };
    MockProductService = __decorate([
        core_1.Injectable()
    ], MockProductService);
    return MockProductService;
}());
exports.MockProductService = MockProductService;
//# sourceMappingURL=product-service.js.map