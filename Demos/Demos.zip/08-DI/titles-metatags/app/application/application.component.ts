import {Component} from '@angular/core';
import {Product, ProductService} from '../product-service/product-service';

// Meta-related imports.
import { Meta, Title } from "@angular/platform-browser";

@Component({
    moduleId:     module.id,
    selector:    'osl-application', 
    templateUrl: 'application.component.html'
})
export default class ApplicationComponent {

    products: Array<Product> = []; 

    constructor(productService: ProductService, meta: Meta, title: Title) { 

        this.products = productService.getProducts(); 

        title.setTitle('SEO Demo - Home');

        meta.addTags([
            { name: 'author',   content: 'John Smith'},
            { name: 'keywords', content: 'angular seo demo, etc.'},
            { name: 'description', content: 'Angular SEO-based App, home page' }
        ]);
    }
}
