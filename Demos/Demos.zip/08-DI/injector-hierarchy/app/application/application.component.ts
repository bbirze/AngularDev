import {Component} from '@angular/core';
import SaleListerComponent from '../sale-lister/sale-lister.component';
import {ISale} from '../sale/sale';
import {Product, ProductService} from '../product-service/product-service';
import {LoggerService} from '../logger-service/logger-service';

@Component({
    moduleId:     module.id,
    selector:    'osl-application', 
    templateUrl: 'application.component.html',
    providers: [ProductService, LoggerService]
})
export default class ApplicationComponent {
    products: Array<Product> = []; 
    newSale: ISale;

    constructor(productService: ProductService, loggerService: LoggerService) { 
        this.products = productService.getProducts(); 
        loggerService.log('ApplicationComponent created');
    }
  
    saleHandler(event: ISale) {
        this.newSale = event;
    }  
}
