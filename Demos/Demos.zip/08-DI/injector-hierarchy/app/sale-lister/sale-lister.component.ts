import {Component, Input} from '@angular/core';
import {ISale} from '../sale/sale';
import {Product} from '../product-service/product-service';
import {LoggerService} from '../logger-service/logger-service';

@Component({
    moduleId:     module.id,
    selector:    'osl-sale-lister',
    templateUrl: 'sale-lister.component.html',
	providers:   [LoggerService],
})
export default class SaleListerComponent {

    constructor(private loggerService : LoggerService) {}

    sales: Array<string> = [];

    private _newSale: ISale;
  
    @Input() set newSale(value: ISale) {
        if (value) {
            let msg:string = value.productDescription + ' [' + value.quantity + ']';
            this.sales.push(msg);
            this.loggerService.log(`SaleListerComponent received new sale: ${msg}`);
        }
    }

    get newSale(): ISale {
        return this._newSale;
    }
}
