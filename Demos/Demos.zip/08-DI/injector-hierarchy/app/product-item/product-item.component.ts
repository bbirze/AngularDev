import {Component, Input, Output, EventEmitter, OnInit} from '@angular/core';
import {ISale} from '../sale/sale';
import {Product} from '../product-service/product-service';
import {LoggerService} from '../logger-service/logger-service';

@Component({
    moduleId:     module.id,
    selector:    'osl-product-item',
    templateUrl: 'product-item.component.html',
    styleUrls:  ['product-item.component.css'],
    providers:  [LoggerService]
})
export default class ProductItemComponent implements OnInit {
    @Input() product: Product;
    @Output() sale: EventEmitter<ISale> = new EventEmitter();
  
    constructor(private loggerService : LoggerService) {}

    ngOnInit() {

        this.loggerService.log(`ProductItemComponent initialized for product ${this.product.description}`);

        setInterval(() => {
            let eventData: ISale = {
                productDescription: this.product.description,
                quantity: 1 + Math.floor(3*Math.random())
            };
            this.sale.emit(eventData);
	}, 1000 + (5000 *Math.random()));
    }
}
