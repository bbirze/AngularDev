import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';

import ApplicationComponent from './application/application.component'
import ProductItemComponent from './product-item/product-item.component'
import SaleListerComponent  from './sale-lister/sale-lister.component'
import {ProductService}  from './product-service/product-service'
import {LoggerService}  from './logger-service/logger-service'

@NgModule({
    imports: [BrowserModule],
    declarations: [ApplicationComponent, ProductItemComponent, SaleListerComponent],
    bootstrap: [ApplicationComponent]
})
export default class AppModule {}


