import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';

import ApplicationComponent from './application/application.component'
import ProductItemComponent from './product-item/product-item.component'

@NgModule({
    imports: [BrowserModule],
    declarations: [ApplicationComponent, ProductItemComponent],
    providers: [
        {provide: "IS_DEV_ENV", useValue: false},
        {provide: "IS_QA_ENV",  useValue: true}
    ],
    bootstrap: [ApplicationComponent]
})
export default class AppModule {}


