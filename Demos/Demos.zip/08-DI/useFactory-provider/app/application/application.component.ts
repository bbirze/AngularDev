import {Component} from '@angular/core';
import {Product, ProductService} from '../product-service/product-service';

class Config {
    constructor(public restUrl: string, public secure: boolean) {}
}

@Component({
    moduleId:     module.id,
    selector:    'osl-application', 
    templateUrl: 'application.component.html',

    providers: [
        ProductService,
        {    
            provide: Config, 
            useFactory: (isDev: boolean, isQA: boolean) => {
                if (isDev || isQA) {
                    return new Config('localhost', false);
                }
                else {
                    return new Config('https://acmecoyotes.com', true);
                 }
            },
            deps: ["IS_DEV_ENV", "IS_QA_ENV"] 
        }
    ]
})
export default class ApplicationComponent {
    products: Array<Product> = []; 

    constructor(productService: ProductService, config: Config) { 
        this.products = productService.getProducts(); 
	console.log(`Configuration info: ${config.restUrl}, ${config.secure}`);
    }
}



                                   
