import {Component} from '@angular/core';
import {Product, ProductService} from '../product-service/product-service';

@Component({
    moduleId:     module.id,
    selector:    'osl-application', 
    templateUrl: 'application.component.html'
})
export default class ApplicationComponent {
    products: Array<Product> = []; 

    constructor(productService : ProductService) { 
        this.products = productService.getProducts(); 
    }
}
