import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule} from '@angular/router';

import AudioComponent from './audio.component'
import VideoComponent from './video.component'

@NgModule({
    imports: [
        CommonModule, 
        RouterModule.forRoot([
            { path: 'audio', component: AudioComponent },
            { path: 'video', component: VideoComponent }
        ])
    ],
    declarations: [
        AudioComponent,
        VideoComponent
    ]
})
export default class MediaModule {}


