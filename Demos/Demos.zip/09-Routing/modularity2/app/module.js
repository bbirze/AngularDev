"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var router_1 = require("@angular/router");
var application_component_1 = require("./application/application.component");
var home_component_1 = require("./home/home.component");
var about_component_1 = require("./about/about.component");
var contact_component_1 = require("./contact/contact.component");
var product_detail_component_1 = require("./product-detail/product-detail.component");
var pagenotfound_component_1 = require("./pagenotfound/pagenotfound.component");
var media_module_1 = require("./media/media.module");
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [
                media_module_1.default,
                platform_browser_1.BrowserModule,
                router_1.RouterModule.forRoot([
                    { path: '', component: home_component_1.default },
                    { path: 'about', component: about_component_1.default },
                    { path: 'contact', component: contact_component_1.default },
                    { path: 'products/:id', component: product_detail_component_1.default, data: { displayPrice: true } },
                    { path: '**', component: pagenotfound_component_1.default }
                ])
            ],
            declarations: [
                application_component_1.default,
                home_component_1.default,
                about_component_1.default,
                contact_component_1.default,
                product_detail_component_1.default,
                pagenotfound_component_1.default
            ],
            bootstrap: [application_component_1.default]
        })
    ], AppModule);
    return AppModule;
}());
exports.default = AppModule;
//# sourceMappingURL=module.js.map