import {Component} from '@angular/core';

@Component({
    template: '<div>OOPS - 404</div>',
    styles:   ['div { color: red; font-size: 100pt; }']
})
export default class PageNotFoundComponent {}