import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {RouterModule} from '@angular/router';

import ApplicationComponent from './application/application.component'
import HomeComponent from './home/home.component'
import AboutComponent from './about/about.component'
import ContactComponent from './contact/contact.component'
import AudioComponent from './audio/audio.component'
import VideoComponent from './video/video.component'
import ProductDetailComponent from './product-detail/product-detail.component'
import PageNotFoundComponent from './pagenotfound/pagenotfound.component'

@NgModule({
    imports: [
        BrowserModule, 
        RouterModule.forRoot([
            { path: '', component: HomeComponent },
            { path: 'about', component: AboutComponent },
            { path: 'contact', component: ContactComponent },
            { path: 'audio', component: AudioComponent },
            { path: 'video', component: VideoComponent },
            { path: 'products/:id', component: ProductDetailComponent, data: {displayPrice: true} }, 
            { path: '**', component: PageNotFoundComponent }
        ])
    ],
    declarations: [
        ApplicationComponent, 
        HomeComponent, 
        AboutComponent, 
        ContactComponent,
        AudioComponent,
        VideoComponent,
        ProductDetailComponent,
        PageNotFoundComponent
    ],
    bootstrap: [ApplicationComponent]
})
export default class AppModule {}


