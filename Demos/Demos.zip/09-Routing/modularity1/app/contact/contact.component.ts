import {Component} from '@angular/core';

@Component({
    template: '<div>This is the Contact view</div>',
    styles:   ['div { background-color: coral; height: 300px; }']
})
export default class ContactComponent {}