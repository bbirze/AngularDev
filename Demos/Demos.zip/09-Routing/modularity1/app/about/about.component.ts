import {Component} from '@angular/core';

@Component({
    template: '<div>This is the About view</div>',
    styles:   ['div { background-color: orange; height: 300px; }']
})
export default class AboutComponent {}