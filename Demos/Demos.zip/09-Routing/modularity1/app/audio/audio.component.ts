import {Component} from '@angular/core';

@Component({
    template: '<div>This is the Audio view</div>',
    styles:   ['div { background-color: aqua; height: 300px; }']
})
export default class AudioComponent {}