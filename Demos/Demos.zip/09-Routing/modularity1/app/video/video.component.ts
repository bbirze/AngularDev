import {Component} from '@angular/core';

@Component({
    template: '<div>This is the Video view</div>',
    styles:   ['div { background-color: magenta; height: 300px; }']
})
export default class VideoComponent {}