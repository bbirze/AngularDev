import {Component} from '@angular/core';
import {Product, ProductService} from '../product-service/product-service';

@Component({
    moduleId: module.id,
    templateUrl: 'home.component.html'
})
export default class HomeComponent {
    products: Array<Product> = []; 

    constructor(productService: ProductService) { 
        this.products = productService.getProducts(); 
    }
}
