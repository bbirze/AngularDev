import {Component, OnInit, OnDestroy} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {ProductService, Product} from '../product-service/product-service';

@Component({
    moduleId: module.id,
    selector: 'osl-product-detail',
    templateUrl: 'product-detail.component.html',
    styleUrls: ['product-detail.component.css'],
    providers: [ProductService]  
})
export default class ProductDetailComponent implements OnInit, OnDestroy {
  
    product: Product;
    displayPrice: boolean;

    subscriberParams: any;
    subscriberData: any;
    
    constructor(private productService: ProductService, private route: ActivatedRoute) {}
    
    ngOnInit() {
        this.subscriberParams = this.route.paramMap.subscribe(paramMap => {
            let id: number = +paramMap.get('id');   // (+) converts string 'id' to a number
            this.product = this.productService.getProductById(id);
        });
        
        this.subscriberData = this.route.data.subscribe(data => {
            this.displayPrice = data['displayPrice']; 
        });     
    }

    ngOnDestroy() {
        this.subscriberParams.unsubscribe();
        this.subscriberData.unsubscribe();
    }
}
