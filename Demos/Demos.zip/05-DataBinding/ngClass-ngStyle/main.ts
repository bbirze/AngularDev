import {Component, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

@Component({
    selector: 'message',
    templateUrl: 'person.html',
    styles: [
        '.modified {font-style: italic}',
        '.highSalary {color: red}'
    ] 
})
class PersonComponent {
  
    firstName: string;
    lastName: string;
    salary: number;
    currentClasses: {};   
    currentStyles: {};   

    constructor() {
        this.firstName = 'Ola';
        this.lastName = 'Nordmann';
        this.salary = 25000;
    }
    
    payRise() {
        this.salary = this.salary + 5000;
        
        this.currentClasses = {
            modified: true,
            highSalary: this.salary >= 40000
        };
        this.currentStyles = {
            'font-size':   this.salary >= 40000 ? 'larger' : 'normal',
            'font-weight': this.salary >= 40000 ? 'bold' : 'normal'
        };
    }
}

// Wrap our component in a module.
@NgModule({
    imports: [BrowserModule],
    declarations: [PersonComponent],
    bootstrap: [PersonComponent]
})
export class AppModule {}

// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

