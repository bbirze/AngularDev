import {Component}              from '@angular/core';
import {NgModule}               from '@angular/core';
import {BrowserModule}          from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

class Car {
    constructor(public make: string, public model: string) {}
}

@Component({
    selector: 'message',
    templateUrl: 'person.html',
    styles: ['.emphasis {color: red}']
})
class PersonComponent {
  
    firstName: string;
    lastName: string;
    nationality: string;
    emailAddress: string;
    companyCar: Car;
    salary: number;
    verbose: boolean;
	
    constructor() {
        this.firstName = 'Ola';
        this.lastName = 'Nordmann';
        this.nationality = 'Norsk';
        this.emailAddress = 'ola.nordmann@mydomain.com';
        this.companyCar = new Car('Bugatti', 'Chiron');
        this.salary = 55000;		
        this.verbose = true;
    }
  
    label() {
        return (this.verbose) ? 'Show brief details' : 'Show verbose details';
    }
	
    onVerboseToggle(event) {
        this.verbose = !this.verbose;
        console.log('Event handler invoked on element ' + event.target);
    }
}

// Wrap our component in a module.
@NgModule({
    imports: [BrowserModule],
    declarations: [PersonComponent],
    bootstrap: [PersonComponent]
})
export class AppModule {}

// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

