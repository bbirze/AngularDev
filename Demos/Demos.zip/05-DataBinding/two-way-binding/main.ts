// You must import FormsModule if you want to use two-way data-binding.
import {FormsModule} from '@angular/forms';

import {Component} from '@angular/core';
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

@Component({
    selector: 'message',
    templateUrl: 'person.html'
})
class PersonComponent {
  
    firstName: string;
    lastName: string;
    nationality: string;
    emailAddress: string;
    salary: number;
  
    constructor() {
        this.firstName = 'Ola';
        this.lastName = 'Nordmann';
        this.nationality = 'Norsk';
        this.emailAddress = 'ola.nordmann@mydomain.com';
        this.salary = 25000;		
    }
	
    payRise() {
        this.salary = this.salary + 5000;
    }

    onSalaryChange($event) {
        this.salary = Number($event.target.value);
    }
}

// Wrap our component in a module. Note that you must specify FormsModule as an import.
@NgModule({
    imports: [BrowserModule, FormsModule],
    declarations: [PersonComponent],
    bootstrap: [PersonComponent]
})
export class AppModule {}

// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

