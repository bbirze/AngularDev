// You must import FormsModule if you want to use two-way data-binding.
import {FormsModule} from '@angular/forms';

import {Component} from '@angular/core';
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

@Component({
    selector: 'message',
    templateUrl: 'employee.html'
})
class EmployeeComponent {
  
    name = "Kari Nordmann";
    skills = "";

    addSkill(newSkill) {
        this.skills += newSkill.value + " ";
        newSkill.value = "";
        newSkill.focus();
    }
}

// Wrap our component in a module. Note that you must specify FormsModule as an import.
@NgModule({
    imports: [BrowserModule, FormsModule],
    declarations: [EmployeeComponent],
    bootstrap: [EmployeeComponent]
})
export class AppModule {}

// App bootstrap.
platformBrowserDynamic().bootstrapModule(AppModule);

