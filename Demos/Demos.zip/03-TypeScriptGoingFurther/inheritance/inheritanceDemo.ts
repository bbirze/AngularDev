﻿// ------------------------------------------------------------------------------------------------
// BankAccount class - this is the base class
// ------------------------------------------------------------------------------------------------

abstract class BankAccount {

    // State.
    private _id: number;
    private _accountHolder: string;
    protected _balance: number = 0.0;
    private static _nextId: number = 1;
    
    // Constructor, getters/setters.
    constructor(accountHolder: string = "") {
        this._accountHolder = accountHolder;
        this._id = BankAccount._nextId++;
    }

    get id(): number {
        return this._id;
    }    
    
    get accountHolder(): string {
        return this. _accountHolder;
    }
    
    set accountHolder(accountHolder: string) {
        this._accountHolder = accountHolder;
    }

    get balance(): number {
        return this._balance;
    }

    // Business methods.
    deposit(amount: number): number {
        this._balance += amount;
        return this._balance;
    }
    
    withdraw(amount: number): number {
        let newBalance: number = this._balance - amount;
        if (newBalance < -1000) {
            throw new RangeError("Cannot exceed overdraft limit");
        }
        else {
            this._balance = newBalance;
        }
        return this._balance;
    }
    
    toString(): string {
        return `[${this._id}] ${this._accountHolder}, ${this._balance}`;
    }
    
    // Abstract methods.
    public abstract get termsAndConditions(): string;
    public abstract get guaranteedLimit(): number;
}

// ------------------------------------------------------------------------------------------------
// SavingsAccount class - this is type of bank account that applies interest.
// ------------------------------------------------------------------------------------------------
class SavingsAccount extends BankAccount {

    // Define additional instance data.
    private _premium: boolean;
    private _goneOverdrawn: boolean;

    // Define additional class data.
    private static _BASIC_INTEREST_RATE   = 0.015;    // Represents 1.5%
    private static _PREMIUM_INTEREST_RATE = 0.030;    // Represents 3.0%
    private static _GUARANTEED_LIMIT      = 50000;    // The first £50,000 of the balance in guaranteed.

    // Constructor.
    constructor(accountHolder: string, premium: boolean) {
        super(accountHolder);
        this._premium = premium;
    }

    // Additional methods.
    applyInterest(): void {
        if (this._balance < 0) {
            // Sorry mate, no interest if you're overdrawn.
        }
        else if (this._premium && !this._goneOverdrawn) {
            this._balance *= (1 + SavingsAccount._PREMIUM_INTEREST_RATE);
        }
        else {
            this._balance *= (1 + SavingsAccount._BASIC_INTEREST_RATE);
        }
    }
    
    // Overrides of members from superclass.
    withdraw(amount: number): number {
        super.withdraw(amount);
        if (this._balance < 0) {
            this._goneOverdrawn = true;
        }
        return this._balance;
    }
    
    toString(): string {
        return `${super.toString()} [${this._premium ? "Premium" : "Normal"} ${this._goneOverdrawn ? "gone overdrawn" : "not gone overdrawn"}]`; 
    }
    
    // Implementation of abstract members from superclass.
    get termsAndConditions(): string {
        return "Savings Accounts accrue interest at 3% pa (premium accounts) or 1.5% otherwise. " +
               "If the account goes overdrawn during the year, the 1.5%  interest rate applies regardless. " + 
               "Savings Accounts are guaranteed by law for the first £" + SavingsAccount._GUARANTEED_LIMIT;
    }
    
    get guaranteedLimit(): number {
        return SavingsAccount._GUARANTEED_LIMIT;
    }    
}


// ------------------------------------------------------------------------------------------------
// CurrentAccount class - this is type of bank account that has cheques.
// ------------------------------------------------------------------------------------------------
class CurrentAccount extends BankAccount {
    
    // Define additional instance data.
    private _chequeBook: number[];
    private _chequesWritten: number = 0;

    // Define additional class data.
    private static _GUARANTEED_LIMIT = 30000;    // The first £30,000 of the balance in guaranteed.

    // Constructor.
    constructor(accountHolder: string, chequeBookSize: number) {
        super(accountHolder);
        this._chequeBook = new Array<number>(chequeBookSize);
    }

    // Additional methods.
    writeCheque(amount: number): void {
        if (this._chequesWritten === this._chequeBook.length) {
            console.log(`Can't write cheque for ${amount}`);
        } 
        else {
            console.log(`Written cheque for ${amount}`);
            this._chequeBook[this._chequesWritten++] = amount;
            this.withdraw(amount);
        }
    }

    displayCheques(): void {
        for (let i = 0; i < this._chequesWritten; i++) {
            console.log(`Cheque ${i}\t:${this._chequeBook[i]}`);
        }
    }
    
    // Overrides of members from superclass.
    toString(): string {
        return `${super.toString()} [${this._chequesWritten} cheques written]`;
    }
        
    // Implementation of abstract members from superclass.
    get termsAndConditions(): string {
        return "Current Accounts do not accrue interest. " +
               "Account holders can request a cheque book, and they can say how many cheques they're likely to need. " + 
               "Current Accounts are guaranteed by law for the first £" + CurrentAccount._GUARANTEED_LIMIT;
    }
    
    get guaranteedLimit(): number {
        return CurrentAccount._GUARANTEED_LIMIT;
    }

}

// ------------------------------------------------------------------------------------------------
// Client code.
// ------------------------------------------------------------------------------------------------
function processAccount(account: BankAccount) {

    console.log("\nProcessing account " + account.id;
    account.withdraw(200);
    account.deposit(300);
    
    // Utilize type-specific behaviour (avoid doing this if possible)
    if (account instanceof SavingsAccount) {
        let temp: SavingsAccount = <SavingsAccount>account;
        temp.applyInterest();
        
    } else if (account instanceof CurrentAccount) { 
        let temp: CurrentAccount = <CurrentAccount>account;
        temp.writeCheque(25.00);
        temp.writeCheque(36.00);
        temp.writeCheque(49.00);
        temp.writeCheque(64.00);
        temp.displayCheques();
    }
    
    console.log(account.toString());
    console.log(account.termsAndConditions;
    console.log(`Additional amount that can be deposited within guarantee limit: ${account.guaranteedLimit - account.balance}`);
}

processAccount(new SavingsAccount("John", true));
processAccount(new CurrentAccount("Esme", 3));
